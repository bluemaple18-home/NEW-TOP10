"""獨立餵合成事件驗證 ES-P1；不查程序、不送訊號、不清理資料。"""

import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
source = Path(sys.argv[1]).resolve()
source_digest = hashlib.sha256(source.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location("es_p1_candidate", source)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

ANCHOR = {"pid": 801, "pidversion": 1, "token": "anchor"}
MIDDLE = {"pid": 802, "pidversion": 1, "token": "middle"}
LEAF = {"pid": 803, "pidversion": 1, "token": "leaf"}


class Case:
    def __init__(self):
        self.reducer = module.LineageReducer("probe-run", "/synthetic/probe-root", "probe-observer", ANCHOR)
        self.seq = 0
        self.counts = {}

    def event(self, kind, **payload):
        self.seq += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1
        return {"version": 1, "run_id": "probe-run", "root": "/synthetic/probe-root",
                "observer_id": "probe-observer", "event_type": kind,
                "global_seq_num": self.seq, "seq_num": self.counts[kind], **payload}

    def feed(self, kind, **payload):
        result = self.reducer.feed(self.event(kind, **payload))
        assert result.cleanup_allowed is False, "離線結果不得授權清理"
        return result

    def nested(self):
        self.feed("ready", anchor=ANCHOR)
        self.feed("fork", parent=ANCHOR, child=MIDDLE, sid=9802)
        self.feed("fork", parent=MIDDLE, child=LEAF, sid=9803)


results = []


def check(name, action):
    try:
        action()
        results.append({"case": name, "pass": True})
    except Exception as exc:
        results.append({"case": name, "pass": False, "error": f"{type(exc).__name__}: {exc}"})


def exit_order(order):
    case = Case()
    case.nested()
    remaining = {item["pid"] for item in order}
    for item in order:
        state = case.feed("exit", process=item)
        remaining.remove(item["pid"])
        assert not state.unknown, state.reason
        assert {identity.pid for identity in state.live_owned} == remaining
        assert not state.bookkeeping_complete, "退出集合清空不應自行標為完成"
    state = case.feed("complete")
    assert state.bookkeeping_complete and not state.unknown
    state = case.reducer.finish()
    assert state.unknown and not state.bookkeeping_complete and not state.cleanup_allowed


for order in itertools.permutations((ANCHOR, MIDDLE, LEAF)):
    check("exit-order-" + "-".join(str(item["pid"]) for item in order), lambda order=order: exit_order(order))


def invalid_then_normal(field, value):
    case = Case()
    case.nested()
    event = case.event("exit", process=LEAF)
    event[field] = value
    state = case.reducer.feed(event)
    assert state.unknown, "缺口或綁定錯誤未失效"
    for item in (LEAF, MIDDLE, ANCHOR):
        state = case.feed("exit", process=item)
        assert state.unknown, "正常後續事件不應解除 unknown"
        assert not state.bookkeeping_complete
    state = case.feed("ready", anchor=ANCHOR)
    assert state.unknown and not state.cleanup_allowed, "再次 ready 不得重置失效"


for field, value in (("global_seq_num", 999), ("run_id", "other-run"),
                     ("root", "/synthetic/other-root"), ("observer_id", "restarted-observer")):
    check("sticky-invalid-" + field, lambda field=field, value=value: invalid_then_normal(field, value))

assert hashlib.sha256(source.read_bytes()).hexdigest() == source_digest, "測試期間候選版本改變，結果作廢"
payload = {"source": str(source), "sha256": source_digest,
           "scope": "offline-only", "cases": results,
           "passed": sum(item["pass"] for item in results), "total": len(results),
           "runtime_stop_proof": False, "cleanup_allowed": False}
print(json.dumps(payload, ensure_ascii=False, indent=2))
raise SystemExit(0 if all(item["pass"] for item in results) else 1)
