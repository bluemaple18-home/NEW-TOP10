"""查核既有檔案與 source，不 import 或執行產品程式。"""
import datetime as dt
import csv
import io
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
D = Path('/Users/mattkuo/TOP10-runtime-automation-bb55fc4')
R = Path('/Users/mattkuo/TOP10-runtime-automation-8fe9366')
manifest = {}

def raw(path):
    b = path.read_bytes()
    manifest[str(path)] = {'sha256':hashlib.sha256(b).hexdigest(), 'bytes':len(b), 'mtime_ns':path.stat().st_mtime_ns}
    return b.decode(errors='replace')

def data(path):
    return json.loads(raw(path))

def fields(d, keys):
    return {k:d.get(k) for k in keys.split()}

def mask(s):
    s = re.sub(r'(https://)?(?:chatgpt.com|gemini.google.com)/[^\s"\']+', '[provider-url-redacted]', s)
    return re.sub(r'\b\d{17,20}\b', '[platform-id-redacted]', s)

result = {'observed_at_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
status = data(D/'artifacts/automation_status_2026-09-08.json')
result['daily_last_success'] = fields(status, 'status mode run_date started_at finished_at dry_run errors')
result['daily_last_success']['steps'] = [fields(s, 'name status started_at finished_at') for s in status['steps']]
for filename in ['clawd_send_status_2026-09-08.json','ops_progress_send_status_2026-09-08.json']:
    d = data(D/'artifacts'/filename)
    summary = fields(d, 'status generated_at message_date dry_run send_attempted exit_code errors')
    response = json.loads(d.get('stdout') or '{}')
    receipt = response.get('payload',{}).get('result',{}).get('receipt',{})
    summary['provider_receipt'] = {'has_platform_message_id':bool(receipt.get('primaryPlatformMessageId')), 'message_id_sha256':hashlib.sha256(str(receipt.get('primaryPlatformMessageId')).encode()).hexdigest() if receipt.get('primaryPlatformMessageId') else None, 'sent_at_epoch_ms':receipt.get('sentAt')}
    result[filename] = summary
rewrite = data(D/'artifacts/clawd_publish_llm_rewrite_2026-09-08.json')
result['rewrite'] = fields(rewrite, 'status ranking_date generated_at selected_model message_chars')
payload = data(D/'artifacts/clawd_publish_payload_2026-09-08.json')
result['payload'] = {'keys':list(payload), **fields(payload, 'ranking_date'), 'top10_count':len(payload.get('top10',[])), 'delivery':fields(payload.get('delivery',{}), 'status mode channel send_attempted')}
ranking = raw(D/'artifacts/ranking_2026-09-08.csv')
result['ranking_row_count'] = len(list(csv.DictReader(io.StringIO(ranking))))
result['september9_absence'] = {name: (D/'artifacts'/name).exists() for name in ['automation_status_2026-09-09.json','ranking_2026-09-09.csv','clawd_publish_payload_2026-09-09.json','clawd_publish_llm_rewrite_2026-09-09.json','clawd_send_status_2026-09-09.json']}
result['stale_automation_status'] = fields(data(D/'artifacts/automation_status.json'), 'status run_date started_at finished_at')
result['log_excerpts'] = {}
for name, tail in [('daily_publish_20260908.log',5000),('daily_publish_20260909.log',5000),('daily_20260909.log',5000),('external_review_provider_preflight_20260908.log',5500),('external_review_provider_preflight_20260921.log',3500)]:
    result['log_excerpts'][name] = mask(raw(D/'logs'/name)[-tail:])
daily = data(D/'logs/storage_safety/daily_latest.json')
result['incident_last_samples'] = [{**fields(s,'timestamp phase host_free_bytes project_bytes rss_bytes swap_bytes memory_pressure_level'), 'processes':[fields(p,'pid ppid rss_bytes command') for p in s.get('process_rss_attribution',[])]} for s in daily['samples'][-4:]]
first, before, cross = daily['samples'][0], daily['samples'][-3], daily['samples'][-2]
result['incident_calculation'] = {
    'runtime_reserve_bytes': max(21474836480, int(first['host_total_bytes']*.10)),
    'last_interval_seconds': cross['timestamp']-before['timestamp'],
    'last_interval_free_decrease':before['host_free_bytes']-cross['host_free_bytes'],
    'last_interval_swap_increase':cross['swap_bytes']-before['swap_bytes'],
    'last_interval_project_increase':cross['project_bytes']-before['project_bytes'],
    'whole_run_free_decrease':first['host_free_bytes']-daily['samples'][-1]['host_free_bytes'],
    'whole_run_project_increase':daily['samples'][-1]['project_bytes']-first['project_bytes'],
}
monitor = data(R/'artifacts/monitor_automation_status.json')
result['monitor_latest'] = {**fields(monitor,'status mode run_date started_at finished_at'), 'steps':[fields(s,'name status') for s in monitor['steps']], 'metadata':monitor['metadata']}
result['monitor_health_history'] = []
for p in sorted((R/'artifacts').glob('model_health_report_2026-09-*.json')):
    if p.name < 'model_health_report_2026-09-09.json':continue
    d = data(p)
    result['monitor_health_history'].append({'path':str(p),**fields(d,'run_date status generated_at'), 'latest_ranking_date':max((x['ranking_date'] for x in d.get('ranking_outcomes',[])),default=None)})
health = data(R/'artifacts/model_health_report_2026-09-22.json')
result['monitor_health_latest'] = fields(health,'status run_date checks monitors')
# 只存需要的 source seam 及檔案 digest，不保存對話 URL 或設定祕密。
seams = [
    (D/'app/storage_safety.py',[(573,587),(623,643),(665,715),(1785,1810)]),
    (D/'scripts/run_with_storage_guard.sh',[(4,8),(34,48)]),
    (D/'scripts/run_daily_publish.sh',[(68,90),(110,141)]),
    (D/'scripts/review_gemini_chrome.sh',[(23,33),(242,257),(536,555),(746,755)]),
    (D/'scripts/review_chatgpt_chrome.sh',[(210,225)]),
    (D/'scripts/run_external_review_host_runner.py',[(510,527),(554,578),(593,600)]),
    (D/'config/automation.yaml',[(8,20),(51,54)]),
    (R/'scripts/daily_retrain.sh',[(67,76),(101,112)]),
    (R/'scripts/run_automation.py',[(276,305),(347,365)]),
    (ROOT/'scripts/run_external_review_host_runner.sh',[(59,74)]),
]
result['source_seams'] = []
for p,ranges in seams:
    lines = raw(p).splitlines()
    result['source_seams'].append({'path':str(p),'excerpts':[{'start':a,'end':b,'text':mask('\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines) if a<=i+1<=b))} for a,b in ranges]})
# 從 source 的 -e 字串還原腳本，僅做字串運算，不呼叫 osascript。
adapter = raw(D/'scripts/review_gemini_chrome.sh')
url_part = re.search(r'^URL_PART="\$\{TOP10_GEMINI_URL_PART:-([^}]+)\}"', adapter, re.M).group(1)
block = adapter.split('run_chrome_js() {',1)[1].split('\n}',1)[0]
lines = []
for line in block.splitlines():
    if "-e '" not in line:continue
    literal = line.strip().removesuffix(' \\')[4:-1]
    literal = literal.replace("'\"$JS_FILE\"'", str(D/'logs/storage_safety/runtime/external-review-preflight/tmp/top10_gemini_review.XXXXXX'))
    literal = literal.replace("'\"$BROWSER_APP\"'", 'Google Chrome')
    literal = literal.replace("'\"$URL_PART\"'", url_part)
    lines.append(literal)
script = '\n'.join(lines)
result['applescript_offset'] = {'reported_span':[544,573], 'reconstructed_text':script[544:573], 'expected':'execute t javascript jsSource', 'matches':script[544:573]=='execute t javascript jsSource', 'assumption':'採 deployed 預設 app／URL 與 guard TMPDIR；XXXXXX 與 mktemp 產生字串同長，未執行 AppleEvent。'}
for name in ['docs/operations/CURRENT_OPERATIONAL_FRONTIER.md','docs/tasks/2026-09-03_P0-NEW-TOP10-AUTOMATION-RUNTIME-RECOVERY.md','docs/tasks/2026-09-08_ACTIVATE-TOP10-RETRAIN-MONITOR-01.md','docs/evidence/ACTIVATE-TOP10-RETRAIN-MONITOR-01/verdict.md','docs/evidence/P0-NEW-TOP10-AUTOMATION-RUNTIME-RECOVERY-A6-INTENT-20260908.md']:
    raw(ROOT/name)
result['source_manifest'] = manifest
(OUT/'details.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sources':len(manifest),'incident':result['incident_calculation'],'applescript_offset':result['applescript_offset'],'health_reports':len(result['monitor_health_history'])},ensure_ascii=False))
