"""重查既有證據及純政策；不執行 workload、瀏覽器、清理或控制面操作。"""

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--require-healthy", action="store_true")
args = parser.parse_args()
base = Path(__file__).resolve().parent
workspace = base.parents[2]
daily_root = Path('/Users/mattkuo/TOP10-runtime-automation-bb55fc4')
monitor_root = Path('/Users/mattkuo/TOP10-runtime-automation-8fe9366')
core = Path('/Users/mattkuo/ai-core')
manifest = {}


def raw(path):
    content = path.read_bytes()
    manifest[str(path)] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
    return content


def read(path):
    return json.loads(raw(path))


snapshot = read(base / 'recheck-2026-09-26.json')
capacity = read(base / 'host-capacity-2026-09-26-native.json')
receipt = read(monitor_root / 'logs/storage_safety/retrain-monitor_latest.json')
live = [row for row in receipt['samples'] if row['phase'] == 'live']
peak = max(live, key=lambda row: row['rss_bytes'])
largest = max(peak['process_rss_attribution'], key=lambda row: row['rss_bytes'])
policies = {name: read(path) for name, path in {
    'top10_project': workspace / 'config/project_sandbox_policy.json',
    'ai_core_project': core / 'config/project_sandbox_policy.json',
    'ai_core_tmp': core / 'config/tmp_artifact_policy.json',
}.items()}

# 僅載入已讀過、只有 dataclasses/datetime/typing 的 deterministic 純政策。
policy_path = monitor_root / 'app/automation/pipeline_policy.py'
raw(policy_path)
spec = importlib.util.spec_from_file_location('recheck_pure_policy', policy_path)
policy = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = policy
spec.loader.exec_module(policy)
profiles = {profile: asdict(policy.evaluate_resource_profile(
    profile=profile, dry_run=False, has_pipeline_window_override=False,
    allow_full_etl=False, allow_heavy_retrain=False, allow_heavy_monitor=False,
)) for profile in ('standard', 'host_full', 'local_safe')}

artifacts = {}
for name, path in {
    'daily_status': daily_root / 'artifacts/automation_status.json',
    'monitor_status': monitor_root / 'artifacts/monitor_automation_status.json',
    'monitor_health': sorted((monitor_root / 'artifacts').glob('model_health_report_2026-09-*.json'))[-1],
}.items():
    data = read(path)
    artifacts[name] = {'path': str(path), **{k: data.get(k) for k in ('status', 'run_date', 'generated_at', 'finished_at')}}
    if name == 'monitor_health':
        artifacts[name]['latest_ranking_date'] = max((r.get('ranking_date', '') for r in data.get('ranking_outcomes', [])), default=None)

comparisons = {}
for relative in ('app/volume_indicators.py', 'scripts/review_gemini_chrome.sh',
                 'scripts/preflight_external_review_providers.py', 'scripts/run_external_review_host_runner.py'):
    raw(workspace / relative)
    raw(daily_root / relative)
    comparisons[relative] = {'workspace': manifest[str(workspace / relative)]['sha256'],
                             'daily_runtime': manifest[str(daily_root / relative)]['sha256']}
for path in (
    monitor_root / 'scripts/monitor_industry_momentum.py',
    monitor_root / 'scripts/research_industry_momentum_walkforward.py',
    monitor_root / 'scripts/run_automation.py',
    daily_root / 'scripts/run_with_storage_guard.sh',
    core / 'scripts/tmp_artifact_lifecycle.py',
):
    raw(path)

latest = {job: rows[-1] for job, rows in snapshot['receipts'].items()}
checks = {
    'loaded_argv_match_installed': all(snapshot['jobs'][j]['loaded_arguments'] == snapshot['jobs'][j]['config']['ProgramArguments'] for j in ('daily', 'external-review-preflight', 'retrain')),
    'daily_stop_matches_persistent_marker': latest['daily']['status'] == 'STOPPED' and latest['daily']['invocation_id'] == snapshot['markers']['daily']['root_invocation_id'],
    'monitor_stop_matches_persistent_marker': receipt['status'] == 'STOPPED' and receipt['invocation_id'] == snapshot['markers']['retrain-monitor']['root_invocation_id'],
    'monitor_peak_below_host_reserve': peak['host_free_bytes'] < capacity['reserve_bytes'],
    'monitor_largest_rss_is_industry_research': 'scripts/monitor_industry_momentum.py' in largest['command'],
    'monitor_config_is_host_full': snapshot['jobs']['retrain']['environment_safe_values']['TOP10_RESOURCE_PROFILE'] == 'host_full',
    'existing_local_safe_can_skip_heavy_monitor': profiles['local_safe']['skip_heavy_monitor'] and not profiles['host_full']['skip_heavy_monitor'],
    'candidate_not_in_daily_runtime': all(item['workspace'] != item['daily_runtime'] for item in comparisons.values()),
    'latest_probe_pass_without_send': snapshot['provider_reports'][-1]['status'] == 'PASS' and snapshot['provider_reports'][-1]['review_packet_sent'] is False,
    'external_review_disabled_unloaded': any('disabled' in x for x in snapshot['jobs']['external-review']['disabled_override']) and snapshot['jobs']['external-review']['loaded_arguments'] is None,
    'different_project_policies': policies['top10_project']['defaults']['max_bytes'] != policies['ai_core_project']['defaults']['max_bytes'],
    'natural_acceptance_still_unproven': all(row['natural_trigger_verified'] is False for row in latest.values()),
}
healthy = {
    'daily': snapshot['markers']['daily'].get('exists') is False and latest['daily']['status'] == 'OK',
    'monitor': snapshot['markers']['retrain-monitor'].get('exists') is False and latest['retrain-monitor']['status'] == 'OK',
    'provider_probe': latest['external-review-preflight']['status'] == 'OK' and snapshot['provider_reports'][-1]['status'] == 'PASS',
}
output = {
    'kind': 'READ_ONLY_RECHECK_NOT_WORKLOAD_REPRODUCTION',
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'snapshot_at_utc': snapshot['observed_at_utc'], 'checks': checks, 'healthy': healthy,
    'passed': sum(checks.values()), 'total': len(checks),
    'monitor_incident': {'invocation_id': receipt['invocation_id'], 'samples': receipt['samples'], 'largest_rss_process_at_peak': largest,
                         'free_delta': live[-1]['host_free_bytes']-live[0]['host_free_bytes'],
                         'swap_delta': live[-1]['swap_bytes']-live[0]['swap_bytes'],
                         'project_delta': live[-1]['project_bytes']-live[0]['project_bytes']},
    'capacity': capacity, 'policies': policies, 'profiles': profiles,
    'artifacts': artifacts, 'candidate_comparisons': comparisons, 'source_manifest': manifest,
}
if not args.require_healthy:
    (base / 'recheck-analysis-2026-09-26.json').write_text(json.dumps(output, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'checks': checks, 'healthy': healthy, 'passed': output['passed'], 'total': output['total']}, ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) and (not args.require_healthy or all(healthy.values())) else 1)
