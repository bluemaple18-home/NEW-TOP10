"""唯讀收集四條既有鏈路；只將遮罩後證據寫到本研究目錄。"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--output', choices=['snapshot.json', 'closing-snapshot.json', 'recheck-2026-09-26.json'], default='snapshot.json')
args = parser.parse_args()
HOME = Path('/Users/mattkuo')
DAILY = HOME / 'TOP10-runtime-automation-bb55fc4'
RETRAIN = HOME / 'TOP10-runtime-automation-8fe9366'
sources = {}
queries = []

def read(path):
    raw = path.read_bytes()
    sources[str(path)] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'mtime_ns': path.stat().st_mtime_ns}
    return raw

def data(path):
    return json.loads(read(path))

def command(argv):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=30, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    queries.append({'argv': argv, 'returncode': p.returncode})
    return p.stdout + p.stderr

def select(d, keys):
    return {k: d.get(k) for k in keys.split()}

def safe_text(value):
    value = re.sub(r'(https://)?(?:chatgpt.com|gemini.google.com)/[^\s"\']+', '[provider-url-redacted]', value)
    return re.sub(r'\b\d{17,20}\b', '[platform-id-redacted]', value)

now = dt.datetime.now(dt.timezone.utc).isoformat()
result = {'observed_at_utc': now, 'jobs': {}, 'receipts': {}, 'markers': {}, 'provider_reports': []}
disabled = command(['launchctl', 'print-disabled', f'gui/{os.getuid()}'])
for job in ['daily', 'external-review-preflight', 'external-review', 'retrain']:
    label = f'com.new-top10.{job}'
    path = HOME / 'Library/LaunchAgents' / f'{label}.plist'
    p = plistlib.loads(read(path))
    state = command(['launchctl', 'print', f'gui/{os.getuid()}/{label}'])
    # 不保存 launchd 的完整 inherited environment。
    state_lines = [line.strip() for line in state.splitlines() if re.search(r'^\s*(path|state|program|working directory|runs|last exit code|pid|type|handle|domain|minimum runtime|exit timeout) =|Could not find|Bad request', line)]
    env = p.get('EnvironmentVariables', {})
    env_safe = {k: v for k, v in env.items() if k in {'PATH','HOME','TOP10_RESOURCE_PROFILE','TOP10_STORAGE_POLICY','TOP10_STORAGE_TRIGGER_TYPE','TOP10_RETRAIN_MODE','TOP10_GEMINI_BROWSER_APP','TOP10_CHATGPT_BROWSER_APP'}}
    loaded_args = re.search(r'\n\targuments = \{\n(.*?)\n\t\}', state, re.S)
    runtime = Path(p.get('WorkingDirectory') or next(a for a in p['ProgramArguments'] if '/scripts/' in a).split('/scripts/')[0])
    result['jobs'][job] = {
        'plist': str(path), 'sha256': sources[str(path)]['sha256'],
        'config': select(p, 'ProgramArguments WorkingDirectory StartCalendarInterval RunAtLoad StandardOutPath StandardErrorPath'),
        'environment_names': sorted(env), 'environment_safe_values': env_safe,
        'launchctl_state': state_lines,
        'loaded_arguments': [line.strip() for line in loaded_args.group(1).splitlines()] if loaded_args else None,
        'disabled_override': [x.strip() for x in disabled.splitlines() if f'"{label}"' in x],
        'runtime_head': command(['git', '-C', str(runtime), 'rev-parse', 'HEAD']).strip(),
        'runtime_branch': command(['git', '-C', str(runtime), 'symbolic-ref', '-q', '--short', 'HEAD']).strip(),
        'runtime_tracked_status': command(['git', '-C', str(runtime), 'status', '--porcelain', '--untracked-files=no']).strip(),
    }

receipt_keys = 'invocation_id job status started_at finished_at last_progress_at trigger_type scheduled_at natural_trigger_verified child_spawned child_exit_code child_terminal_status final_process_group_quiescent acceptance_status artifact_run_date publish_or_provider_result reasons restart_denied lock_owner_status runtime_sha'
for root, job in [(DAILY,'daily'), (DAILY,'external-review-preflight'), (RETRAIN,'retrain-monitor')]:
    base = root / 'logs/storage_safety'
    rows = []
    paths = sorted((base / 'receipts' / job).glob('*.json'))
    paths += [base / f'{job}_latest.json']
    for path in paths:
        d = data(path)
        row = {'path': str(path), **select(d, receipt_keys)}
        samples = d.get('samples', [])
        if samples:
            row['sample_count'] = len(samples)
            row['first_sample'] = select(samples[0], 'timestamp phase host_free_bytes host_total_bytes project_bytes project_file_count rss_bytes swap_bytes')
            row['last_sample'] = select(samples[-1], 'timestamp phase host_free_bytes host_total_bytes project_bytes project_file_count rss_bytes swap_bytes')
            row['sample_extrema'] = {k: {'min': min(s[k] for s in samples if s.get(k) is not None), 'max': max(s[k] for s in samples if s.get(k) is not None)} for k in ['host_free_bytes','project_bytes','project_file_count','rss_bytes','swap_bytes']}
        rows.append(row)
        if job == 'daily':
            row['all_samples'] = [select(s, 'timestamp phase host_free_bytes project_bytes project_file_count rss_bytes swap_bytes') for s in samples]
    result['receipts'][job] = rows
    marker = base / 'restart_denied' / f'{job}.json'
    result['markers'][job] = select(data(marker), 'job reasons root_invocation_id automatic_clear_allowed') if marker.exists() else {'exists': False}
    log = base / f'{job}.log'
    if log.exists():
        result.setdefault('guard_log_tail', {})[job] = safe_text(read(log).decode(errors='replace')[-8000:])

for path in sorted((DAILY / 'artifacts/external_review').glob('2026-09-*/provider_preflight_*.json')):
    d = data(path)
    if d.get('date', '') < '2026-09-01':
        continue
    row = {'path': str(path), **select(d, 'date generated_at status mode review_packet_sent summary'), 'checks': []}
    for c in d.get('checks', []):
        row['checks'].append({**select(c, 'provider status provider_status blocker'), 'evidence': select(c.get('evidence', {}), 'exit_code has_composer has_send_button stderr_tail')})
    result['provider_reports'].append(row)

policy = data(DAILY / 'docs/operations/top10-storage-policy.json')
result['policy_top_level_keys'] = list(policy)
result['policy_host'] = policy.get('host')
result['host_disk_usage'] = dict(zip(['total','used','free'], shutil.disk_usage(DAILY)))
result['source_manifest'] = sources
result['queries'] = queries
(OUT / args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'observed_at': now, 'sources':len(sources), 'receipts':{k:len(v)-1 for k,v in result['receipts'].items()}, 'provider_reports':len(result['provider_reports']), 'output':str(OUT/args.output)}, ensure_ascii=False))
