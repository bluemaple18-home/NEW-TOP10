"""研究證據斷言；不重現 workload，也不宣稱 natural acceptance。"""
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--require-healthy', action='store_true')
args = p.parse_args()
root = Path(__file__).resolve().parent
s = json.loads((root/'closing-snapshot.json').read_text())
initial = json.loads((root/'snapshot.json').read_text())
d = json.loads((root/'details.json').read_text())
daily = s['receipts']['daily'][-1]
latest_provider = s['provider_reports'][-1]
checks = {
    'loaded_arguments_match_three_enabled_jobs': all(s['jobs'][j]['loaded_arguments']==s['jobs'][j]['config']['ProgramArguments'] for j in ['daily','external-review-preflight','retrain']),
    'production_source_hashes_unchanged_during_collection': all(s['source_manifest'].get(path,{}).get('sha256')==v['sha256'] for path,v in initial['source_manifest'].items()),
    'daily_stop_matches_marker':daily['status']=='STOPPED' and daily['invocation_id']==s['markers']['daily']['root_invocation_id'],
    'daily_trigger_sample_below_reserve':d['incident_last_samples'][-2]['host_free_bytes']<d['incident_calculation']['runtime_reserve_bytes'],
    'daily_project_bytes_under_budget':daily['last_sample']['project_bytes']<6442450944,
    'daily_project_files_under_budget':daily['last_sample']['project_file_count']<60000,
    'daily_stopped_before_new_ranking_and_send':not any(d['september9_absence'].values()),
    'last_success_top10_and_send_receipt':d['payload']['top10_count']==10 and d['clawd_send_status_2026-09-08.json']['provider_receipt']['has_platform_message_id'],
    'chatgpt_pass_gemini_timeout':latest_provider['checks'][0]['status']=='PASS' and '-1712' in latest_provider['checks'][1]['evidence']['stderr_tail'],
    'applescript_timeout_span_matches_execute_js':d['applescript_offset']['matches'],
    'preflight_sent_no_packet':latest_provider['review_packet_sent'] is False,
    'external_review_disabled_unloaded':any('disabled' in v for v in s['jobs']['external-review']['disabled_override']) and s['jobs']['external-review']['loaded_arguments'] is None,
    'monitor_13_successes_one_capacity_denial':sum(x['status']=='OK' for x in s['receipts']['retrain-monitor'][:-1])==13 and sum(x['status']=='NO-GO' for x in s['receipts']['retrain-monitor'][:-1])==1,
    'monitor_latest_is_monitor_only':d['monitor_latest']['mode']=='monitor' and all(x['name']!='model.train' for x in d['monitor_latest']['steps']),
    'monitor_latest_terminal_ok_but_health_warn':d['monitor_latest']['status']=='OK' and d['monitor_health_latest']['status']=='WARN',
    'natural_acceptance_not_proven':all(x['natural_trigger_verified'] is False for v in s['receipts'].values() for x in v),
}
healthy = {
    'daily_restart_marker_absent':s['markers']['daily'].get('exists') is False,
    'daily_latest_terminal_ok':daily['status']=='OK',
    'latest_provider_preflight_pass':latest_provider['status']=='PASS',
}
output = {'kind':'READ_ONLY_EVIDENCE_ASSERTIONS_NOT_WORKLOAD_REPRODUCTION','checks':checks,'healthy_observations':healthy,'passed':sum(checks.values()),'total':len(checks)}
if not args.require_healthy:
    (root/'assertions.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(output,ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) and (not args.require_healthy or all(healthy.values())) else 1)
